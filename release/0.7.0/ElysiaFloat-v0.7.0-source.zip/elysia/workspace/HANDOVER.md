# 交接说明（Handover）

更新时间：2026-10-16
当前阶段：G2 已完成（本地代码 + 自动验证 + 构建）；下一步进入 G3
最新测试包：`apk/phases/ElysiaFloat-g2-handover-debug.apk`
SHA-256：`4e795476320257b634002eb7d413dba19ddf885d29814141896d968515dbb835`

## 1. 一句话现状

ElysiaFloat 是一个 Android 悬浮窗 AI 助手（聊天 + 手机 Agent + 文件工作区 + 插件平台）。
0.6.2 之后一直在本地持续开发，**尚未提交、未推送**；`main` 相对 `origin/main` 仅 ahead 1（只多一个文档提交）。
前端已拆分为 `android/app/src/main/assets/src/`，构建时由 `tools/build-html.js` 合并生成单文件 `index.html`。

## 2. 代码与文档的权威入口

| 用途 | 位置 |
|---|---|
| 唯一执行计划（阶段/依赖/出口） | `workspace/plans/MASTER-EXECUTION-PLAN.md` |
| 唯一问题总表（编号/证据/状态） | `workspace/issues/ISSUE-REGISTER.md` |
| 工作区导航与事实快照 | `workspace/STATUS.md` |
| 执行证据 | `workspace/work-logs/` |
| 用户确认/产品取舍 | `workspace/discussions/` |
| 长期规则 | `workspace/decisions/` |
| 测试版 APK | `apk/phases/`（同目录带 `-SHA256SUMS`） |
| 稳定技术文档 | `docs/` |

## 3. 已验证可用的能力

- 悬浮窗、小球、胶囊、迷你播放器；
- 多模型/多服务商对话，Function Calling 多轮工具；
- 长期记忆（概览 + 按需检索）；
- 插件：Manifest v1、权限声明、JS 沙箱、HTTP 插件、工具开关、本地/远程市场；
- Agent：L1/L2/L3、应用白名单、无障碍读屏、截屏、动作执行、重复动作熔断；
- 文件工作区：input/working/output/logs/snapshots、索引、写入前快照、回滚；
- 音乐：多源搜索 + 分页、播放、歌词、收藏、历史、队列、缓存面板、下载进度、单曲删除、主题跟随；
- 设置：单一保存按钮，保存链路 null 安全，异常可见。

## 4. G2 这轮实际做了什么

1. 运行上下文隔离：`ChatSession` / `QuickOperation` / `AgentTask` 各自携带显式任务；
   `chatReqTools`、`execTool`、`buildTools`、插件宿主调用都改用显式任务，不再隐式读 `currentTask()`。
2. 任务状态机：新增 `TASK_TRANSITIONS`，非法迁移记录 `INVALID_STATE_TRANSITION` 并保留原状态。
3. 取消边界：`ACTIVE_RUN_TASK_ID`、模型请求 taskId 绑定、运行令牌、插件沙箱挂起取消、截图等待取消。
4. 长任务预算：非聊天任务默认 1200 秒（20 分钟），设置上限 7200 秒；旧 90 秒配置自动迁移。
5. 工具轮数：`0 = 按任务时间`，不再退化成 5；设置 UI 增加对应选项。
6. 插件能力：新增 `read_screen_once`、`music.control`；插件面板 / Agent tools Schema / 提示词三处一致，单项开关互不误伤。
7. 设置页：移除重复的悬浮保存按钮；底部操作条 `sticky bottom:28px`（随时可点，避开 22px 窗口缩放热区）；
   修复 `#set-gd-api` 缺失导致的保存静默失败；27 处读取改为 null 安全。

## 5. 验证门（每次改代码都要跑）

```bash
cd android
node tools/build-html.js --check   # 源码模块与 index.html 一致
node tools/smoke.js                # 全部通过才算过
./build.sh assembleDebug           # 构建成功
```

当前三项全绿。smoke 里已包含：音乐解析/面板、插件权限与沙箱、G2 上下文与取消、
长任务预算、设置保存控件存在性、缩放遮挡回归、引导页与 WebView 分级等。

## 6. 未完成 / 待设备验证

**设备验证（不能靠本地测试替代）**
- 真机插件面板看到音乐组并生效；带 `music.control` / `device.read` 的第三方插件授权允许与拒绝；
- 长任务暂停/恢复/停止、跨重启恢复；
- 音乐真实源（GD Studio / Meting）、302/403/429/签名过期、离线与息屏播放、公共目录可见性；
- 文件写入/快照/回滚在 Android 11+ 与厂商文件管理器的表现。

**代码待做（按计划顺序）**
- G3：统一 RequestManager（requestId、超时预算、取消、重试、3xx 策略、响应大小/MIME 校验、统一错误码、来源健康）；
- G4 尾：音乐真实源适配与真机收口；
- G5：DeviceTask 完整 PLAN→ACT→VERIFY 调度与高风险确认；
- G6：真正的 `FullscreenActivity`（当前只有 Overlay 最大化）；
- G7：文件解析（PDF/Office/EPUB/ZIP 安全）、原子写入、符号链接边界、Kotlin 单测；
- G8：Termux token 校验 + run_id + 输出回传 + 取消；Root 审计与取消；Shizuku 真实接入；
- G9：插件签名根、撤销、审核流水线；外部 Agent 下载/哈希/启动/停止/回传；
- G10：Release 签名、CI、真机矩阵、`release/latest.json` 同步。

## 7. 明确的红线

1. 不把 Debug 包当正式发布包；发布必须有签名、SHA-256、真机记录。
2. 不扩高权限能力（Root/Shizuku/外部 Agent）在 G3 之前。
3. 插件拿不到原始 `Android.*` 桥、Root、Shizuku、任意 shell。
4. 屏幕/网页/文件内容是不可信数据，不得覆盖安全规则。
5. 未提交就别说"已推送"；没有证据就把状态写成"待验"，不写"已完成"。
6. 测试失败时先修代码或修断言，不允许为了让 smoke 变绿而放宽检查。

## 8. 接手第一天建议动作

1. 跑一遍第 5 节的三条验证命令，确认基线全绿。
2. 打开 `apk/phases/` 里最新的 `ElysiaFloat-g2-handover-debug.apk` 装机，按第 6 节设备清单抽查 3～5 项。
3. 读 `workspace/issues/ISSUE-REGISTER.md`，把本轮新发现的问题补编号。
4. 开始 G3：先建 `RequestManager`（先统一模型请求，再接插件/音乐/更新），每接一处跑一次 smoke。

## 9. 已知遗留问题（非阻塞）

- `node tools/build-html.js --verify-migration` 仍会失败：旧迁移基线已过期，`--check` 才是当前正确门；
- `release/latest.json` 仍指向旧 0.6.2 包，与本地构建不一致（G10 处理）；
- `via_ai_history` legacy 写入仍存在于记忆/插件/导入等路径（G2-002 后续清理项）。
